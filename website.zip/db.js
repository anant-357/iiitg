const mysql = require('mariadb')

const pool = mysql.createPool({
		host: "node-cc-app-id.cnjl6jnnj86z.ap-south-1.rds.amazonaws.com",
		user: 'user',
		password: 'user1234',
		database: 'nodeAppDB',
		waitForConnection:true,
		connectionLimit:10,
		queueLimit:0
});

module.exports = pool
