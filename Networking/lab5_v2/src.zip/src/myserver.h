#define PORT 8080
#define DATA_SIZE 500
#define LOCALHOST "127.0.0.1"
#define TIMEOUT 20



