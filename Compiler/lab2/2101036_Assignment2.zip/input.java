// Your First Program

/**
 this is documentation code
 so this should come in doc.txt file
 */

/**
   another doc code
   this will also be in doc.txt
*/

class HelloWorld {
    public static void main(String[] args) {
        /* this will also be removed as it is
        a comment */
        System.out.println("Hello, World!"); 
    }
}

