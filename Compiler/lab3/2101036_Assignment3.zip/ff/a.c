#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct rule{
  char symbol[2];
  char produces[10];
};

char* first(struct rule rules[10], char symbol){
  printf("\nchecking: %c", symbol);
  struct rule check;
  strcpy(check.symbol, "");
  for(int i=0; i<10; i++){
    if (rules[i].symbol[0] == symbol){
      strcpy(check.symbol, rules[i].symbol);
      strcpy(check.produces, rules[i].produces);
        }
  }
  if(strcmp(check.symbol,"") == 0)
    return "not found";

  char* ret = (char *)malloc(10* sizeof(char));
  
  int reti = 0;
  for(int i=0; i< strlen(check.produces); i++){
    if(i==0){
      if(check.produces[i]>='A' && check.produces[i]<='Z')
        strcat(ret, first(rules, check.produces[i]));
      else{
        ret[reti++] = check.produces[i];
        ret[reti] = '\0';
      }
    }
    else if (check.produces[i] == '|'){
      if(check.produces[i+2]>='A' && check.produces[i+2]<='Z')
        strcat(ret, first(rules, check.produces[i+2]));
      else{
        ret[reti++] = check.produces[i+2];
        ret[reti] = '\0';
      }
    }
  }
  
  return ret;
}

char* follow(struct rule rules[10], char symbol){
  return "";
}

void print_rules(struct rule rules[10]){
  for(int i = 0; i < 10; i++){
    if(strcmp(rules[i].symbol,"") == 0)
      break;
    printf("%s:%s\n", rules[i].symbol, rules[i].produces);
  }
}

int main(){
  FILE *in;
  in = fopen("productions","r");
  if(in == NULL)
    printf("Unable to open file");

  struct rule rules[10];
  int i = 0;
  while(fscanf(in,"%[^-]->%[^\n]",rules[i].symbol, rules[i].produces) == 2){
    i++;
    fscanf(in, "\n");
  }
  print_rules(rules);
  printf("\n%s\n",first(rules, 'A'));
  
  fclose(in);
}
