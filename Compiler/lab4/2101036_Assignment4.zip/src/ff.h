#include "utils.h"

char* first(rule rules[N_RULES], char symbol);

char* follow(rule rules[N_RULES], char symbol);

